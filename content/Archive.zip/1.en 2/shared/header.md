---
header_navigation:
    - title: "Home"
      link: "/"
    - title: "About Us"
      link: "/about-us"
    - title: "Projects"
      link: "/projects"
    - title: "Locations"
      link: "/#storeLocations"
    - title: "Products & Services"
      sub_items:
          - title: "Kitchen Design Solutions"
            link: "/services/stylish-kitchen-and-furniture-designs"
          - title: "Interior Decoration Services"
            link: "/services/exclusive-interior-design-solutions"
          - title: "Custom Manufacturing"
            link: "/services/wood-and-alabaster-solutions"

cta:
    title: "Contact us"
    link: "/contact-us"
---
