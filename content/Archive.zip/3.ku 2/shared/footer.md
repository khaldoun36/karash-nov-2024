---
footer_navigation:
    - section_title: "کۆمپانیا"
      section_links:
          - page_url: "/about-us"
            link_text: "دەربارەی ئێمە"
          - page_url: "/projects"
            link_text: "پڕۆژەکانمان"
          - page_url: "https://www.linkedin.com/company/karashco/jobs/"
            link_text: "هەلی کار"

    - section_title: "بەرهەم و خزمەتگوزارییەکان"
      section_links:
          - page_url: "/services/stylish-kitchen-and-furniture-designs"
            link_text: "چارەسەری دیزاینی چێشتخانە"
          - page_url: "/services/exclusive-interior-design-solutions"
            link_text: "خزمەتگوزاری دیکۆری ناوخۆیی"
          - page_url: "/services/wood-and-alabaster-solutions"
            link_text: "دروستکردنی تایبەت"

    - section_title: "سەرچاوەکانی کڕیار"
      section_links:
          - page_url: "/contact-us"
            link_text: "پەیوەندی بە تیمەکەمانەوە بکە"
          - page_url: "/contact-us"
            link_text: "پشتگیری دوای فرۆشتن"
          - page_url: "/#storeLocations"
            link_text: "شوێنەکانمان بدۆزەرەوە"
---
