---
footer_navigation:
    - section_title: "Company"
      section_links:
          - page_url: "/about-us"
            link_text: "About Us"
          - page_url: "/projects"
            link_text: "Our Projects"
          - page_url: "https://www.linkedin.com/company/karashco/jobs/"
            link_text: "Career Opportunities"

    - section_title: "Products and Services"
      section_links:
          - page_url: "/services/stylish-kitchen-and-furniture-designs"
            link_text: "Kitchen Design Solutions"
          - page_url: "/services/exclusive-interior-design-solutions"
            link_text: "Interior Decoration Services"
          - page_url: "/services/wood-and-alabaster-solutions"
            link_text: "Custom Manufacturing"

    - section_title: "Customer Resources"
      section_links:
          - page_url: "/contact-us"
            link_text: "Contact Our Team"
          - page_url: "/contact-us"
            link_text: "After-Sales Support"
          - page_url: "/#storeLocations"
            link_text: "Find Our Locations"
---
