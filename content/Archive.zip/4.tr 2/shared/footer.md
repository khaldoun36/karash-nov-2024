---
footer_navigation:
    - section_title: "Kurumsal"
      section_links:
          - page_url: "/about-us"
            link_text: "Hakkımızda"
          - page_url: "/projects"
            link_text: "Projelerimiz"
          - page_url: "https://www.linkedin.com/company/karashco/jobs/"
            link_text: "Kariyer Fırsatları"

    - section_title: "Ürün ve Hizmetler"
      section_links:
          - page_url: "/services/stylish-kitchen-and-furniture-designs"
            link_text: "Mutfak Tasarım Çözümleri"
          - page_url: "/services/exclusive-interior-design-solutions"
            link_text: "İç Dekorasyon Hizmetleri"
          - page_url: "/services/wood-and-alabaster-solutions"
            link_text: "Özel Üretim"

    - section_title: "Müşteri Kaynakları"
      section_links:
          - page_url: "/contact-us"
            link_text: "Ekibimizle İletişime Geçin"
          - page_url: "/contact-us"
            link_text: "Satış Sonrası Destek"
          - page_url: "/#storeLocations"
            link_text: "Mağazalarımızı Bulun"
---
