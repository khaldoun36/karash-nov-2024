---
formTitle: "تواصل مع فريقنا المتخصص"
formDescription: "هل لديك استفسارات حول منتجاتنا أو خدماتنا؟ هل ترغب في تحويل فكرة مشروعك إلى واقع ناجح؟ تواصل معنا لنكتشف سويًا كيف يمكننا دعمك."
options:
    - label: "خدمات ما بعد البيع"
      value: "after-sales-support"
    - label: "استفسار عن خدماتنا"
      value: "service-inquiry"
btnText: "إرسال"
---
