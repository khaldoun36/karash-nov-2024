---
header_navigation:
    - title: "الرئيسية"
      link: "/"
    - title: "من نحن"
      link: "/about-us"
    - title: "مشاريعنا"
      link: "/projects"
    - title: "مواقع معارضنا"
      link: "/#storeLocations"
    - title: "المنتجات والخدمات"
      sub_items:
          - title: "حلول تصميم المطابخ"
            link: "/services/stylish-kitchen-and-furniture-designs"
          - title: "خدمات التصميم الداخلي"
            link: "/services/exclusive-interior-design-solutions"
          - title: "التصنيع المخصص"
            link: "/services/wood-and-alabaster-solutions"

cta:
    title: "تواصل معنا"
    link: "/contact-us"
---
