---
title: "Biz Kimiz"
description:
    - "Karash Company olarak sadece mobilya üretmiyoruz – kalıcı miraslar inşa ediyoruz. Yaklaşık yirmi yıldır, mekanları dönüştürüyor ve beklentilerin ötesine geçiyoruz. 2004'ten beri tutkumuz, köklü gelenekleri en son yeniliklerle harmanlayan olağanüstü yaşam alanları yaratmaya bizi yönlendiriyor."

    - "Yolculuğumuz mükemmelliğin bir kanıtıdır. İkisi Türkiye'de ve üçü Erbil'de olmak üzere beş ileri teknoloji üretim tesisimizle sektörün gerçek öncüleri olarak kendimizi kanıtladık. Kapsamlı yeteneklerimiz mobilyanın ötesine geçerek, yapay mermer yüzeyler, elektrik ekipmanları, aksesuarlar, duvar kağıtları, korkuluklar ve özel ahşap ve demir kapıların özel üretimini içeriyor. Irak genelinde on bir şubeden oluşan geniş ağımız, bizi ev tasarımı ve üretiminde lider bir güç olarak konumlandırıyor."

    - "Biz sadece bir şirket değiliz; yaşam alanlarını olağanüstü deneyimlere dönüştürmeye kendini adamış vizyonerleriz. Kaliteye olan kararlı arayışımız ve uluslararası genişleme planlarımız, dokunduğumuz her eve eşsiz zarafet, işlevsellik ve ustalık getirme konusundaki sarsılmaz bağlılığımızı yansıtıyor."
---
