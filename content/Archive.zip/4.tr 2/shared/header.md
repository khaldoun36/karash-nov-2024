---
header_navigation:
    - title: "Ana Sayfa"
      link: "/"
    - title: "Hakkımızda"
      link: "/about-us"
    - title: "Projelerimiz"
      link: "/projects"
    - title: "Mağazalarımız"
      link: "/#storeLocations"
    - title: "Ürün ve Hizmetler"
      sub_items:
          - title: "Mutfak Tasarım Çözümleri"
            link: "/services/stylish-kitchen-and-furniture-designs"
          - title: "İç Dekorasyon Hizmetleri"
            link: "/services/exclusive-interior-design-solutions"
          - title: "Özel Üretim"
            link: "/services/wood-and-alabaster-solutions"

cta:
    title: "İletişime Geçin"
    link: "/contact-us"
---
