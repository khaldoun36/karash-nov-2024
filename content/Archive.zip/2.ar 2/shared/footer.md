---
footer_navigation:
    - section_title: "الشركة"
      section_links:
          - page_url: "/about-us"
            link_text: "من نحن"
          - page_url: "/projects"
            link_text: "مشاريعنا"
          - page_url: "https://www.linkedin.com/company/karashco/jobs/"
            link_text: "فرص العمل"

    - section_title: "المنتجات والخدمات"
      section_links:
          - page_url: "/services/stylish-kitchen-and-furniture-designs"
            link_text: "حلول تصميم المطابخ"
          - page_url: "/services/exclusive-interior-design-solutions"
            link_text: "خدمات التصميم الداخلي"
          - page_url: "/services/wood-and-alabaster-solutions"
            link_text: "التصنيع المخصص"

    - section_title: "خدمة العملاء"
      section_links:
          - page_url: "/contact-us"
            link_text: "تواصل مع فريقنا"
          - page_url: "/contact-us"
            link_text: "خدمة ما بعد البيع"
          - page_url: "/#storeLocations"
            link_text: "مواقع معارضنا"
---
