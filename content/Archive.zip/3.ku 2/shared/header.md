---
header_navigation:
    - title: "سەرەکی"
      link: "/"
    - title: "دەربارەی ئێمە"
      link: "/about-us"
    - title: "پڕۆژەکان"
      link: "/projects"
    - title: "شوێنەکان"
      link: "/#storeLocations"
    - title: "بەرهەم و خزمەتگوزارییەکان"
      sub_items:
          - title: "دیزاینی چێشتخانە"
            link: "/services/stylish-kitchen-and-furniture-designs"
          - title: "خزمەتگوزاری دیکۆری ناوخۆیی"
            link: "/services/exclusive-interior-design-solutions"
          - title: "دروستکردنی تایبەت"
            link: "/services/wood-and-alabaster-solutions"

cta:
    title: "پەیوەندیمان پێوە بکە"
    link: "/contact-us"
---
